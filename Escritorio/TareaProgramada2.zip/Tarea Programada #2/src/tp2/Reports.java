package tp2;

import static tp2.BACSystem.model;

public class Reports {
    String rowsValues [] = new String[5];
    int counter;
    int auxCounter;
    
    public void generateData () {
        if (counter < BAC.clientsRecord.getSize()) {
            rowsValues [0] = (String) BAC.clientsRecord.getItemIndex(counter, 2);
            rowsValues [1] = (String) BAC.clientsRecord.getItemIndex(counter, 3);
            rowsValues [2] = (String) BAC.clientsRecord.getItemIndex(counter, 4);
            rowsValues [3] = (String) BAC.clientsRecord.getItemIndex(counter, 1);
            rowsValues [4] = BAC.getDate();
            model.addRow(rowsValues);
            counter++;
        }
    }
    
    public void sortBy (int index) {
        BAC.clientsRecord.bubbleSort(index);
        if (auxCounter < BAC.clientsRecord.getSize()) {
            rowsValues [0] = (String) BAC.clientsRecord.getItemIndex(auxCounter, 2);
            rowsValues [1] = (String) BAC.clientsRecord.getItemIndex(auxCounter, 3);
            rowsValues [2] = (String) BAC.clientsRecord.getItemIndex(auxCounter, 4);
            rowsValues [3] = (String) BAC.clientsRecord.getItemIndex(auxCounter, 1);
            rowsValues [4] = BAC.getDate();
            model.addRow(rowsValues);
            auxCounter++;
        }
    }
    
    public void wipeTable () {
        int a = model.getRowCount()-1;
        for(int i=a;i>=0;i--) {  
            model.removeRow(i);
        }
    }
}
