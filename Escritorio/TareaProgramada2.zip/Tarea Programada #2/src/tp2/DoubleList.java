package tp2;

public class DoubleList <E> {
    private Node firstNode;
    private Node lastNode;
    private int size;

    public class Node <E> {
        E data1;
        E data2;
        E data3;
        E data4;
        Node <E> next;
        Node <E> previous;

        public Node() {
            this.data1 = null;
            this.data2 = null;
            this.data3 = null;
            this.data4 = null;
            this.next = null;
            this.previous = null;
        }

        public Node(E inputData1, E inputData2, E inputData3, E inputData4) {
            this.data1 = inputData1;
            this.data2 = inputData2;
            this.data3 = inputData3;
            this.data4 = inputData4;
            next = null;
            previous = null;
        }

        public Node(E inputData1, E inputData2, E inputData3,  E inputData4, Node nextNode) {
            this.data1 = inputData1;
            this.data2 = inputData2;
            this.data3 = inputData3;
            this.data4 = inputData4;
            next = nextNode;
        }

        public E getData1 () {
            return this.data1;
        }

        public void setData1 (E data) {
            this.data1 = data;
        }
        
        public E getData2 () {
            return this.data2;
        }

        public void setData2 (E data) {
            this.data2 = data;
        }
        
        public E getData3 () {
            return this.data3;
        }

        public void setData3 (E data) {
            this.data3 = data;
        }
        public E getData4 () {
            return this.data4;
        }

        public void setData4 (E data) {
            this.data4 = data;
        }
    }

    public DoubleList () {
            this.firstNode = null;
            this.lastNode = null;
            this.size = 0;
    }

    public boolean isEmpty() { 
        return firstNode == null;
    }

    public void printList() { 
        if (isEmpty()) {
            System.err.println("Sorry! Empty List");
        }
        else {
            StringBuilder result = new StringBuilder();
            Node aux = firstNode;
            for (int i = 0; i < this.size && aux != null; i++) {
                result.append(aux.data1);
                result.append(" ");
                result.append(aux.data2);
                result.append(" ");
                result.append(aux.data3);
                result.append(" ");
                result.append(aux.data4);
                result.append("\n");
                aux = aux.next;
            }
            System.out.println(result);
        }
    }

    /*public void addBeginning(E inputData1, E inputData2, E inputData3, E inputData4) {
        if (isEmpty()) {
            firstNode = new Node(inputData1, inputData2, inputData3, inputData4);
            firstNode.previous = null;
        }	
        else {
            Node newNode = new Node(inputData1, inputData2, inputData3, inputData4, firstNode);
            firstNode.previous = newNode;
            firstNode = newNode;
        }
        this.size++;
    }*/

    public void addEnd(E inputData1, E inputData2, E inputData3, E inputData4) {
        if (isEmpty()) {
            firstNode = new Node(inputData1, inputData2, inputData3, inputData4);
            firstNode.previous = null;
        }
        else {
            Node aux = firstNode;
            while(aux.next != null) {
                aux = aux.next;
            }
            aux.next = new Node(inputData1, inputData2, inputData3, inputData4);
            aux.next.previous = aux;
        }
        this.size++;
    }

    /*public void addPosition(E imputData1, int pos) {
        if(isEmpty()) {
            firstNode = new Node(imputData1);
        }
        else {
            if(pos <= 1) {
                Node newNode = new Node(imputData1);
                newNode.next = firstNode;
                firstNode = newNode;
                firstNode.next.previous = firstNode;
            }
            else {
                Node aux = firstNode;
                int i = 2;
                while((i!=pos)&&(aux.next != null)) {
                    i++;
                    aux = aux.next;
                }
                Node newNode = new Node(imputData1);
                newNode.next = aux.next;
                aux.next = newNode;
                newNode.previous = aux;		
            }
        }
        this.size++;
    }*/

    public void deleteBeginning() {
        if (isEmpty()) {
            throw new Error("Sorry! Not found elements");
        }
        else {
            if(firstNode.next == null) {
                firstNode = null;
            }
            else {
                firstNode = firstNode.next;
                firstNode.previous = null;
            }
            this.size--;
        }	
    }

    /*public void deleteEnd() {
        if(isEmpty()) {
            throw new Error("Sorry! Not found elements");
        }
        else {
            if(firstNode.next == null) {
                firstNode = null;
            }
            else {
                Node actual = firstNode;
                while(actual.next!=null) {
                    actual = actual.next;
                }
                actual.previous.next = null;
            }
            this.size--;
        }
    }*/

    public void deletePosition(int pos) {
        if(this.isEmpty()) {
            System.err.println("Sorry! Not found elements");
        }
        else {
            Node actual = firstNode;
            int i = 0;
            while((i != pos)&&(actual.next != null)) {
                i++;
                actual = actual.next;
            }
            if (pos == 0) {
                deleteBeginning();
            }
            else if(i == pos) {
                 {
                    actual.previous.next = actual.next;
                    if (actual.next != null) {
                        actual.next.previous = actual.previous;
                    }
                }
            }
            this.size--;
        }
    }

    public void reverse () {
        Node next = firstNode;
        Node previous = null;
        while(!(isEmpty())) {
            next = firstNode.next;
            firstNode.next = previous;
            previous = firstNode;
            firstNode = next;		
        }
        firstNode = previous;
    }

    public int size () {
        return this.size;
    }

    public E getElementPosition(int pos, int data) {
        E result = null;
        if (data == 1) {
            result = (E) this.getNode(pos).data1;
        }
        else if (data == 2) {
            result = (E) this.getNode(pos).data2;
        }
        else if (data == 3) {
            result = (E) this.getNode(pos).data3;
        }
        else if (data == 4) {
            result = (E) this.getNode(pos).data4;
        }
        return result;
    }

    public Node getNode(int pos) {
        if (pos >= this.size() || pos < 0) {
                return null;
        }
        Node actualNode = this.firstNode;
        for (int i = 0; i < pos ; i++) {
            actualNode = actualNode.next;
        }
        return actualNode;
    }

    public void swap(Node nodex, Node nodey) {
        E element1 = (E) nodex.getData1();
        E element2 = (E) nodex.getData2();
        E element3 = (E) nodex.getData3();
        E element4 = (E) nodex.getData4();
        nodex.setData1(nodey.getData1());
        nodex.setData2(nodey.getData2());
        nodex.setData3(nodey.getData3());
        nodex.setData4(nodey.getData4());
        nodey.setData1(element1);
        nodey.setData2(element2);
        nodey.setData3(element3);
        nodey.setData4(element4);
    }

    public void bubbleSort (int index) {
        for (int i = this.size() - 1; i > 0; i--) {
            for (int j = 0; j < i; j++) {
                if((this.getElementPosition(j + 1, index).toString().compareTo(this.getElementPosition(j, index).toString())) < 0) {
                    this.swap(this.getNode(j), this.getNode(j + 1));
                }
            }
        }
    }

    public void concatenate (DoubleList list) {
        Node aux = list.firstNode;
        int index = 0;
        while (index < list.size()) {
            this.addEnd((E) aux.data1, (E) aux.data2, (E) aux.data3, (E) aux.data4);
            aux = aux.next;
            index++;
        }
    }

    /*public String toString() {
        Node actualNode = this.firstNode;
        StringBuffer result = new StringBuffer();
        for (int i = 0; actualNode != null; i++) {
            if (i > 0) {
                result.append(" ");
            }
            Object dato = actualNode.getData1();
            result.append(dato == null ? "" : dato);
            actualNode = actualNode.next;
        }
        System.out.println(result.toString());
        return result.toString();
    }*/

    public void wipeList () {
        while (!isEmpty()) {
            this.deleteBeginning();
        }
    }

    public int compareTo (E item1, E item2) {
        int comparable = 0;
        if (item1.getClass().getSimpleName().equals("Integer") && item2.getClass().getSimpleName().equals("Integer")) {
            if (Integer.parseInt(item1.toString()) > Integer.parseInt(item2.toString())) {
                comparable = -1;
            }
            else if (Integer.parseInt(item1.toString()) == Integer.parseInt(item2.toString())) {
                comparable = 0;
            }
            else {
                comparable = 1;
            }
        }
        if (item1.getClass().getSimpleName().equals("String") && item2.getClass().getSimpleName().equals("String")) {
            if (item1.toString().compareTo(item2.toString()) < 0) {
                comparable = 1;
            }
            else if (item1.toString().compareTo(item2.toString()) == 0) {
                comparable = 0;
            }
            else {
                comparable = -1;
            }
        }
        return comparable;
    }
    
    public void changeItem (int index, E item) {
        this.getNode(index).setData1(item);
    }
    
    /*public int getMaxValue() {
        int max;
        max = (int) (Comparable) this.getElementPosition(0);
        for (int i = 1; i < this.size; i++) {
            if ((int) (Comparable) this.getElementPosition(i) > max) {
                max = (int) (Comparable) this.getElementPosition(i);
            }
        }
        return max;
    }*/         
}
