package tp2;

public class Queue <E> {
    private final DoubleList queue;
    
    public Queue () {
        this.queue = new DoubleList();
    }
    
    public void queue (E item1, E item2, E item3, E item4) {
        this.queue.addEnd(item1, item2, item3, item4);
    }
    
    public E dequeue () {
        E result = (E) this.queue.getElementPosition(0, 4);
        this.queue.deleteBeginning();
        return result;
    }
    
    public E getfront () {
        return (E) this.queue.getNode(0);
    }
    
    public E getlast () {
        return (E) this.queue.getNode(this.queue.size() - 1);
    }
    
    public int getSize () {
        return this.queue.size();
    }
    
    public void displayQueue () {
        this.queue.printList();
    }
    
    public void dequeueIndex (int index) {
        this.queue.deletePosition(index);
    }
    
    public E getItemIndex (int index, int dataIndex) {
        return (E) this.queue.getElementPosition(index, dataIndex);
    }
    
    public boolean isEmpty () {
        return this.queue.isEmpty();
    }
    
    public void bubbleSort (int index) {
        this.queue.bubbleSort(index);
    }
}
