package tp2;

import javax.swing.JOptionPane;
import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class BAC <E> {
    private Queue clients;
    public static Queue clientsRecord;
    private final String PATTERN_EMAIL = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@" +
                                         "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
    
    public BAC () {
        this.clients = new Queue();
        BAC.clientsRecord = new Queue();
    }
        
    private CashBox cashBox1 = new CashBox();
    private CashBox cashBox2 = new CashBox();
    private CashBox cashBox3 = new CashBox();
    private CashBox cashBox4 = new CashBox();
    private CashBox cashBox5 = new CashBox();
    private CashBox cashBox6 = new CashBox();
 
    private class CashBox {
        private String cashBoxName;
        private boolean isAble; 
        private boolean isBusy;
        
        public CashBox () {
            this.isAble = false;
            this.isBusy = false;
            this.cashBoxName = null;
        }
        
        public CashBox (String cashBoxName, boolean status, boolean condition) {
            this.cashBoxName = cashBoxName;
            this.isAble = status;
            this.isBusy = condition;
        }
        
        public void setAble (boolean status) {
            this.isAble = status;
        }
        
        public void setBusy (boolean condition) {
            this.isBusy = condition;
        }
        
        public void setName (String cashBoxName) {
            this.cashBoxName = cashBoxName;
        }
        
        public boolean getAble () {
            return this.isAble;
        }
        
        public boolean getBusy () {
            return this.isBusy;
        }
        
        public String getName () {
            return this.cashBoxName;
        }
    }
    
    public void setCashBoxStatus (int index, boolean status, boolean condition) {
        if (index == 1) {
            cashBox1 = new CashBox("CashBox " + index, status, condition);
        }
        else if (index == 2) {
            cashBox2 =  new CashBox("CashBox " + index, status, condition);
        }
        else if (index == 3) {
            cashBox3 =  new CashBox("CashBox " + index, status, condition);
        }
        else if (index == 4) {
            cashBox4 =  new CashBox("CashBox " + index, status, condition);
        }
        else if (index == 5) {
            cashBox5 =  new CashBox("CashBox " + index, status, condition);
        }
        else if (index == 6) {
            cashBox6 =  new CashBox("CashBox " + index, status, condition);
        }
    }
    
    public boolean getValue (String cashBoxName, int value) {
        CashBox temp = null;
        if (cashBoxName.equals(cashBox1.getName())) {
            temp = cashBox1;
        }
        else if (cashBoxName.equals(cashBox2.getName())) {
            temp = cashBox2;
        }
        else if (cashBoxName.equals(cashBox3.getName())) {
            temp = cashBox3;
        }
        else if (cashBoxName.equals(cashBox4.getName())) {
            temp = cashBox4;
        }
        else if (cashBoxName.equals(cashBox5.getName())) {
            temp = cashBox5;
        }
        else if (cashBoxName.equals(cashBox6.getName())) {
            temp = cashBox6;
        }
        if (value == 1) {
            return temp.isAble;
        }
        else {
            return temp.isBusy;
        }
    }
    
    public String attendingClient () throws Exception {
        String result = null;
        if (cashBox1.isAble && !cashBox1.isBusy) {
            result = cashBox1.cashBoxName + " " + attendNext();
            cashBox1.setBusy(true);
        }
        else if (cashBox2.isAble && !cashBox2.isBusy) {
            result = cashBox2.cashBoxName + " " + attendNext();
            cashBox2.setBusy(true);
        }
        else if (cashBox3.isAble && !cashBox3.isBusy) {
            result = cashBox3.cashBoxName + " " + attendNext();
            cashBox3.setBusy(true);
        }
        else if (cashBox4.isAble && !cashBox4.isBusy) {
            result = cashBox4.cashBoxName + " " + attendNext();
            cashBox4.setBusy(true);
        }
        else if (cashBox5.isAble && !cashBox5.isBusy) {
            result = cashBox5.cashBoxName + " " + attendNext();
            cashBox5.setBusy(true);
        }
        else if (cashBox6.isAble && !cashBox6.isBusy) {
            result = cashBox6.cashBoxName + " " + attendNext();
            cashBox6.setBusy(true);
        }
        else {
            JOptionPane.showMessageDialog(null, "Unable CashBoxes");
        }
        return result;
    }
    
    public void addClient (E eMail, E name, E user) {
        if (validateEmail((String) eMail)) {
            String request = (String) generateCode((String) user);
            String [] temp = new String[2];
            temp [0] = (String) name;
            temp [1] = request;
            sendEmail((String) eMail, "sanjoseBAC@gmail.com", temp);
            this.clients.queue(eMail, name, user, request);
            BAC.clientsRecord.queue(eMail, name, user, request);
            JOptionPane.showMessageDialog(null, "Request Generated Correctly" + "\n" + "Request N° " + request);
        }
        else {
            JOptionPane.showMessageDialog(null, "Invalid E-mail Address");
        }
    }
    
    public E generateCode (String priority) {
        StringBuilder code = new StringBuilder();
        int counter = 1;
        for (int i = 0; i < BAC.clientsRecord.getSize(); i++) {
            if (BAC.clientsRecord.getItemIndex(i, 3).equals(priority)) {
                counter++;
            }
        }
        switch (priority) {
            case "Disable":
                code.append("A00").append(counter);
                break;
            case "Old":
                code.append("B00").append(counter);
                break;
            case "Pregnant":
                code.append("C00").append(counter);
                break;
            case "Corporate":
                code.append("D00").append(counter);
                break;
            case "Regular":
                code.append("E00").append(counter);
                break;
        }
        return (E) code.toString();
    }
    
    public E attendNext () throws Exception {
        E result = null;
        if (this.clients.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Nobody in queue");
        }
        else {
            result = (E) ((E) "Attending: " + (String) getNext());
            return result;
        }
        throw new Error();
    }
    
    public E getNext () {
        clients.bubbleSort(4);
        return (E) clients.dequeue();
    }
    
    public void releaseCashBox (int index) {
        setCashBoxStatus(index, true, false);
    }
    
    public void disableCashBox (int index) {
        setCashBoxStatus(index, false, false);
    }
    
    public boolean validateEmail (String eMail) {
        Pattern pattern = Pattern.compile(PATTERN_EMAIL);
        Matcher matcher = pattern.matcher(eMail);
        return matcher.matches();
    }
    
    public void sendEmail (String to, String from, String text []) {
        final String username = from;
        final String password = "passwordBAC";
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
        Session session = Session.getInstance(props,
          new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
          });
        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("fromSomeone@gmail.com"));
            message.setRecipients(Message.RecipientType.TO,
            InternetAddress.parse(to));
            message.setSubject("BAC San José Request N°");
            BodyPart messageBodyPart = new MimeBodyPart();
            messageBodyPart.setText("BAC San José Confirmation Request\nUsername: " + text[0] + "\nRequest N°: " + text[1] + "\nRequested at: " + getDate());
            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(messageBodyPart);
            messageBodyPart = new MimeBodyPart();
            String filename = "logoBAC.png";
            DataSource source = new FileDataSource(filename);
            messageBodyPart.setDataHandler(new DataHandler(source));
            messageBodyPart.setFileName(filename);
            multipart.addBodyPart(messageBodyPart);
            message.setContent(multipart );
            Transport.send(message);
        } 
        catch (MessagingException e) {
        }
    }
    
    public static String getDate () {
        Date date = new Date();
        DateFormat hourdateFormat = new SimpleDateFormat("HH:mm:ss dd/MM/yyyy");
        return hourdateFormat.format(date);
    }
}