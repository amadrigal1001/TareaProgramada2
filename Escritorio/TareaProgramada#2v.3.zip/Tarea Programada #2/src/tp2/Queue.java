package tp2;

/**DEFINICIÓN DE LA CLASE QUEUE Y ATRIBUTOS*/
public class Queue <E> {
    private final DoubleList queue;
    
    /**CONSTRUCTOR DE LA CLASE QUEUE*/
    public Queue () {
        this.queue = new DoubleList();
    }
    
    /**MÉTODO PARA ENCOLAR ELEMENTOS*/
    public void queue (E item1, E item2, E item3, E item4) {
        this.queue.addEnd(item1, item2, item3, item4);
    }
    
    /**MÉTODO PARA DESENCOLAR ELEMENTOS*/
    public E dequeue () {
        E result = (E) this.queue.getElementPosition(0, 4);
        this.queue.deleteBeginning();
        return result;
    }
    
    /**MÉTODO PARA OBTENER EL PRIMER ELEMENTO DE LA COLA*/
    public E getfront () {
        return (E) this.queue.getNode(0);
    }
    
    /**MÉTODO PARA OBTENER EL ÚLTIMO ELEMENTO DE LA COLA*/
    public E getlast () {
        return (E) this.queue.getNode(this.queue.getSize() - 1);
    }
    
    /**MÉTODO PARA OBTENER EL TAMAÑO DE LA COLA*/
    public int getSize () {
        return this.queue.getSize();
    }
    
    /**MÉTODO PARA MOSTRAR EN PANTALLA LA COLA*/
    public void displayQueue () {
        this.queue.printList();
    }
    
    /**MÉTODO PARA OBTENER EL ELEMENTO EN UNA POSICIÓN DETERMINADA DE LA COLA*/
    public E getItemIndex (int index, int dataIndex) {
        return (E) this.queue.getElementPosition(index, dataIndex);
    }
    
    /**MÉTODO PARA DETERMINAR SI LA COLA ESTÁ VACÍA*/
    public boolean isEmpty () {
        return this.queue.isEmpty();
    }
    
    /**ALGORITMO DE ORDENAMIENTO BUBBLESORT ADAPTADO A STRINGS*/
    public void bubbleSort (int index) {
        this.queue.bubbleSort(index);
    }
}