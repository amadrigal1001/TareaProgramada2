package tp2;

import javax.swing.JOptionPane;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**DEFINICION DE LA CLASE PRINCIPAL Y ATRIBUTOS*/
public class BAC <E> {
    private Queue clients;
    protected static Queue clientsRecord;
    
    /**CONSTRUCTOR DE LA CLASE BAC*/
    public BAC () {
        this.clients = new Queue();
        BAC.clientsRecord = new Queue();
    }
    
    /**VARIABLES GLOBALES CORRESPONDIENTES AL NÚMERO DE CAJAS*/
    private CashBox cashBox1 = new CashBox();
    private CashBox cashBox2 = new CashBox();
    private CashBox cashBox3 = new CashBox();
    private CashBox cashBox4 = new CashBox();
    private CashBox cashBox5 = new CashBox();
    private CashBox cashBox6 = new CashBox();
 
    /**DEFINICIÓN DE LA CLASE CASHBOX Y ATRIBUTOS*/
    private class CashBox {
        private String cashBoxName;
        private boolean isAble; 
        private boolean isBusy;
        
        /*CONSTRUCTOR DE LA CLASE CASHBOX*/
        public CashBox () {
            this.isAble = false;
            this.isBusy = false;
            this.cashBoxName = null;
        }
        
        /*CONSTRUCTOR DE LA CLASE CASHBOX*/
        public CashBox (String cashBoxName, boolean status, boolean condition) {
            this.cashBoxName = cashBoxName;
            this.isAble = status;
            this.isBusy = condition;
        }
        
        /**MÉTODO PARA SELECCIONAR EL ESTATUS DE LAS CAJAS*/
        public void setAble (boolean status) {
            this.isAble = status;
        }
        
        /**MÉTODO PARA SELECCIONAR LA DISPONIBILIDAD DE LAS CAJAS*/
        public void setBusy (boolean condition) {
            this.isBusy = condition;
        }
        
        /**MÉTODO PARA SELECCIONAR EL NOMBRE DE LAS CAJAS*/
        public void setName (String cashBoxName) {
            this.cashBoxName = cashBoxName;
        }
        
        /**MÉTODO PARA OBTENER EL ESTATUS DE LAS CAJAS*/
        public boolean getAble () {
            return this.isAble;
        }
        
        /**MÉTODO PARA OBTENER EL ESTADO DE LAS CAJAS*/
        public boolean getBusy () {
            return this.isBusy;
        }
        
        /**MÉTODO PARA OBTENER EL NOMBRE DE LAS CAJAS*/
        public String getName () {
            return this.cashBoxName;
        }
    }
    
    /**MÉTODO PARA ESTABLECER EL ESTATUS GENERAL DE LAS CAJAS*/
    public void setCashBoxStatus (int index, boolean status, boolean condition) {
        if (index == 1) {
            cashBox1 = new CashBox("CashBox " + index, status, condition);
        }
        else if (index == 2) {
            cashBox2 =  new CashBox("CashBox " + index, status, condition);
        }
        else if (index == 3) {
            cashBox3 =  new CashBox("CashBox " + index, status, condition);
        }
        else if (index == 4) {
            cashBox4 =  new CashBox("CashBox " + index, status, condition);
        }
        else if (index == 5) {
            cashBox5 =  new CashBox("CashBox " + index, status, condition);
        }
        else if (index == 6) {
            cashBox6 =  new CashBox("CashBox " + index, status, condition);
        }
    }
    
    /*MÉTODO PARA OBTENER EL ESTATUS DE DISPONIBILIDAD U OCUPACIÓN DE LAS CAJAS*/
    public boolean getValue (String cashBoxName, int value) {
        CashBox temp = null;
        if (cashBoxName.equals(cashBox1.getName())) {
            temp = cashBox1;
        }
        else if (cashBoxName.equals(cashBox2.getName())) {
            temp = cashBox2;
        }
        else if (cashBoxName.equals(cashBox3.getName())) {
            temp = cashBox3;
        }
        else if (cashBoxName.equals(cashBox4.getName())) {
            temp = cashBox4;
        }
        else if (cashBoxName.equals(cashBox5.getName())) {
            temp = cashBox5;
        }
        else if (cashBoxName.equals(cashBox6.getName())) {
            temp = cashBox6;
        }
        if (value == 1) {
            return temp.isAble;
        }
        else {
            return temp.isBusy;
        }
    }
    
    /**MÉTODO PARA ATENDER A LOS CLIENTES EN COLA*/
    public String attendingClient () throws Exception {
        String result = null;
        if (cashBox1.isAble && !cashBox1.isBusy) {
            result = cashBox1.cashBoxName + " " + attendNext();
            cashBox1.setBusy(true);
        }
        else if (cashBox2.isAble && !cashBox2.isBusy) {
            result = cashBox2.cashBoxName + " " + attendNext();
            cashBox2.setBusy(true);
        }
        else if (cashBox3.isAble && !cashBox3.isBusy) {
            result = cashBox3.cashBoxName + " " + attendNext();
            cashBox3.setBusy(true);
        }
        else if (cashBox4.isAble && !cashBox4.isBusy) {
            result = cashBox4.cashBoxName + " " + attendNext();
            cashBox4.setBusy(true);
        }
        else if (cashBox5.isAble && !cashBox5.isBusy) {
            result = cashBox5.cashBoxName + " " + attendNext();
            cashBox5.setBusy(true);
        }
        else if (cashBox6.isAble && !cashBox6.isBusy) {
            result = cashBox6.cashBoxName + " " + attendNext();
            cashBox6.setBusy(true);
        }
        else {
            JOptionPane.showMessageDialog(null, "Unable CashBoxes");
        }
        return result;
    }
    
    /**MÉTODO PARA AGREGAR UN CLIENTE A LA COLA*/
    public void addClient (E eMail, E name, E user) {
        if (EmailManagement.validateEmail((String) eMail)) {
            String request = (String) generateCode((String) user);
            String [] temp = new String[2];
            temp [0] = (String) name;
            temp [1] = request;
            EmailManagement.sendEmail((String) eMail, temp);
            this.clients.queue(eMail, name, user, request);
            BAC.clientsRecord.queue(eMail, name, user, request);
            JOptionPane.showMessageDialog(null, "Request Generated Correctly" + "\n" + "Request N° " + request);
        }
        else {
            JOptionPane.showMessageDialog(null, "Invalid E-mail Address");
        }
    }
    
    /**MÉTODO PARA GENERAR EL CÓDIGO CORRESPONDIENTE AL USUARIO*/
    public E generateCode (String priority) {
        StringBuilder code = new StringBuilder();
        int counter = 1;
        for (int i = 0; i < BAC.clientsRecord.getSize(); i++) {
            if (BAC.clientsRecord.getItemIndex(i, 3).equals(priority)) {
                counter++;
            }
        }
        switch (priority) {
            case "Disable":
                Reports.disable++;
                code.append("A00").append(counter);
                break;
            case "Old":
                Reports.old++;
                code.append("B00").append(counter);
                break;
            case "Pregnant":
                Reports.pregnant++;
                code.append("C00").append(counter);
                break;
            case "Corporate":
                Reports.corporate++;
                code.append("D00").append(counter);
                break;
            case "Regular":
                Reports.regular++;
                code.append("E00").append(counter);
                break;
        }
        return (E) code.toString();
    }
    
    /**MÉTODO PARA ATENDER AL SIGUIENTE EN LA COLA*/
    public E attendNext () throws Exception {
        E result = null;
        if (this.clients.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Nobody in queue");
        }
        else {
            result = (E) ((E) "Attending: " + (String) getNext());
            return result;
        }
        throw new Error();
    }
    
    /**MÉTODO PARA OBTENER EL SIGUIENTE EN LA COLA*/
    public E getNext () {
        clients.bubbleSort(4);
        return (E) clients.dequeue();
    }
    
    /**MÉTODO PARA DESOCUPAR LAS CAJAS*/
    public void releaseCashBox (int index) {
        setCashBoxStatus(index, true, false);
    }
    
    /**MÉTODO PARA DESHABILITAR LAS CAJAS*/
    public void disableCashBox (int index) {
        setCashBoxStatus(index, false, false);
    }
    
    /**MÉTODO PARA GENERAR LAS FECHAS*/
    public static String getDate () {
        Date date = new Date();
        DateFormat hourdateFormat = new SimpleDateFormat("HH:mm:ss dd/MM/yyyy");
        return hourdateFormat.format(date);
    }
}