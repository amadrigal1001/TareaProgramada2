package tp2;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import static tp2.BACSystem.model;

/**DEFINICIÓN DE LA CLASE REPORTS Y ATRIBUTOS*/
public class Reports {
    private final String rowsValues [] = new String[5];
    private int counter;
    private int auxCounter;
    protected static int disable;
    protected static int old;
    protected static int pregnant;
    protected static int corporate;
    protected static int regular;
    
    /**MÉTODO PARA GENERAR LA INFORMACIÓN REGISTRADA*/
    public void generateData () {
        if (counter < BAC.clientsRecord.getSize()) {
            rowsValues [0] = (String) BAC.clientsRecord.getItemIndex(counter, 2);
            rowsValues [1] = (String) BAC.clientsRecord.getItemIndex(counter, 3);
            rowsValues [2] = (String) BAC.clientsRecord.getItemIndex(counter, 4);
            rowsValues [3] = (String) BAC.clientsRecord.getItemIndex(counter, 1);
            rowsValues [4] = BAC.getDate();
            model.addRow(rowsValues);
            counter++;
        }
    }
    
    /**MÉTODO PARA EL ORDENAMIENTO DE LA TALBA*/
    public void sortBy (int index) {
        BAC.clientsRecord.bubbleSort(index);
        if (auxCounter < BAC.clientsRecord.getSize()) {
            rowsValues [0] = (String) BAC.clientsRecord.getItemIndex(auxCounter, 2);
            rowsValues [1] = (String) BAC.clientsRecord.getItemIndex(auxCounter, 3);
            rowsValues [2] = (String) BAC.clientsRecord.getItemIndex(auxCounter, 4);
            rowsValues [3] = (String) BAC.clientsRecord.getItemIndex(auxCounter, 1);
            rowsValues [4] = BAC.getDate();
            model.addRow(rowsValues);
            auxCounter++;
        }
    }
    
    /**MÉTODO PARA REESTABLECER LOS VALORES POR DEFECTO DE LA TABLA*/
    public void wipeTable () {
        int a = model.getRowCount()-1;
        for(int i=a;i>=0;i--) {  
            model.removeRow(i);
        }
    }
    
    /**MÉTODO PARA GENERAR EL GRÁFICO PASTEL*/
    public void generatePieChart () {
        DefaultPieDataset data = new DefaultPieDataset();
        data.setValue("Disable", disable);
        data.setValue("Old", old);
        data.setValue("Pregnant", pregnant);
        data.setValue("Corporate", corporate);
        data.setValue("Regular", regular);
        JFreeChart chart = ChartFactory.createPieChart(
         "BAC San José Report",
         data,
         true,
         true,
         false);
        ChartFrame frame = new ChartFrame("BAC San José Report", chart);
        frame.pack();
        frame.setVisible(true);
    }
    
    /**MÉTODO PARA GENERAR EL GRÁFICO DE BARRAS*/
    public void generateBarChart () {
        DefaultCategoryDataset data = new DefaultCategoryDataset ();
        data.setValue(disable, "Disable", "Code A");
        data.setValue(old, "Old", "Code B");
        data.setValue(pregnant, "Pregnant", "Code C");
        data.setValue(corporate, "Corporate", "Code D");
        data.setValue(regular, "Regular", "Code E");
        JFreeChart chart = ChartFactory.createBarChart("BAC San José Report", null, null, data);
        ChartFrame frame = new ChartFrame("BAC San José Report", chart);
        frame.pack();
        frame.setVisible(true);
    }
}