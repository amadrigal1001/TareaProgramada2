package tp2;

import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import static tp2.BAC.getDate;

/**DEFINICIÓN DE LA CLASE EMAILMANAGEMENT Y ATRIBUTOS*/
public class EmailManagement {
    private static final String patternEmail = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@" +
                                         "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
    
    /**MÉTODO PARA VALIDAR DIRECCIONES DE CORREOS ELECTRÓNICOS*/
    public static boolean validateEmail (String eMail) {
        Pattern pattern = Pattern.compile(patternEmail);
        Matcher matcher = pattern.matcher(eMail);
        return matcher.matches();
    }
    
    /**MÉTODO PARA ENVIAR CORREOS ELECTRÓNICOS*/
    public static void sendEmail (String to, String text []) {
        final String username = "sanjoseBAC@gmail.com";
        final String password = "passwordBAC";
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
        Session session = Session.getInstance(props,
          new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
          });
        sendEmailAux (session, to, text);
    }
    
    /**MÉTODO AUXILIAR PARA ENVIAR CORREOS ELECTRÓNICOS*/
    public static void sendEmailAux (Session session, String to, String text []) {
        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("fromSomeone@gmail.com"));
            message.setRecipients(Message.RecipientType.TO,
            InternetAddress.parse(to));
            message.setSubject("BAC San José Request N°");
            BodyPart messageBodyPart = new MimeBodyPart();
            messageBodyPart.setText("BAC San José Confirmation Request\nUsername: " + text[0] + "\nRequest N°: " + text[1] + "\nRequested at: " + getDate());
            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(messageBodyPart);
            messageBodyPart = new MimeBodyPart();
            String filename = "logoBAC.png";
            DataSource source = new FileDataSource(filename);
            messageBodyPart.setDataHandler(new DataHandler(source));
            messageBodyPart.setFileName(filename);
            multipart.addBodyPart(messageBodyPart);
            message.setContent(multipart );
            Transport.send(message);
        } 
        catch (MessagingException e) {
        }
    }
}
