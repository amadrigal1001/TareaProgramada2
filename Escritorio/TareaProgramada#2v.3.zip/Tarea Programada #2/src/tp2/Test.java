//package tp2;
//
//import static tp2.BAC.clients;
//public class Test {
//    public static void main (String [] args) {
//        BAC bank = new BAC ();
//        bank.addClient("amadrigal1001@gmail.com", "Andrés", "Regular");
//        bank.addClient("wen_mv@hotmail.com", "Wen", "Regular");
//        bank.addClient("suhellen@hotmail.com", "Suhellen", "Pregnant");
//        bank.addClient("ita@gmail.com", "Ita", "Old");
//        bank.addClient("ito@outlook.com", "Ito", "Old");
//        bank.addClient("unknow@yahoo.com", "Unknow", "Disable");
//        
//        //clients.displayQueue();
//        
//        //clients.bubbleSort(4);
//        
//        //clients.displayQueue();
//        
//        /*bank.attendNext();
//        bank.attendNext();
//        bank.attendNext();
//        bank.attendNext();
//        bank.attendNext();
//        bank.attendNext();*/
//        
//        bank.setCashBoxStatus(1, true, false);
//        bank.setCashBoxStatus(2, true, false);
//        //bank.setCashBoxStatus(3, true, false);
//        //bank.setCashBoxStatus(4, true, false);
//        //bank.getCashBoxStatus(1);
//        bank.getCashBoxStatus(1);
//        bank.attendingClient();
//        bank.attendingClient();
//        bank.attendingClient();
//        bank.attendingClient();
//        bank.getCashBoxStatus(1);
//        //System.out.println(clients.getSize());
//        //System.out.println(clients.getItemIndex(4, 4));
//        
//        
//        //clients.displayQueue();
//    }
//}
