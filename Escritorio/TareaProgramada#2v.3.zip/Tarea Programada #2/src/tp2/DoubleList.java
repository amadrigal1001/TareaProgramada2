package tp2;

/**DEFINICIÓN DE LA CLASE DOUBLELIST Y ATRIBUTOS*/
public class DoubleList <E> {
    private Node firstNode;
    private Node lastNode;
    private int size;

    /**DEFINICIÓN DE LA CLASE NODE Y ATRIBUTOS*/
    public class Node <E> {
        E data1;
        E data2;
        E data3;
        E data4;
        Node <E> next;
        Node <E> previous;

        /**CONSTRUCTOR DE LA CLASE NODE*/
        public Node() {
            this.data1 = null;
            this.data2 = null;
            this.data3 = null;
            this.data4 = null;
            this.next = null;
            this.previous = null;
        }

        /**CONSTRUCTOR DE LA CLASE NODE*/
        public Node(E inputData1, E inputData2, E inputData3, E inputData4) {
            this.data1 = inputData1;
            this.data2 = inputData2;
            this.data3 = inputData3;
            this.data4 = inputData4;
            next = null;
            previous = null;
        }

        /**CONSTRUCTOR DE LA CLASE NODE*/
        public Node(E inputData1, E inputData2, E inputData3,  E inputData4, Node nextNode) {
            this.data1 = inputData1;
            this.data2 = inputData2;
            this.data3 = inputData3;
            this.data4 = inputData4;
            next = nextNode;
        }

        /**MÉTODO PARA OBTENER EL DATO 1 DE LOS NODOS*/
        public E getData1 () {
            return this.data1;
        }

        /**MÉTODO PARA ESTABLECER EL DATO 1 DE LOS NODOS*/
        public void setData1 (E data) {
            this.data1 = data;
        }
        
        /**MÉTODO PARA OBTENER EL DATO 2 DE LOS NODOS*/
        public E getData2 () {
            return this.data2;
        }

        /**MÉTODO PARA ESTABLECER EL DATO 2 DE LOS NODOS*/
        public void setData2 (E data) {
            this.data2 = data;
        }
        
        /**MÉTODO PARA OBTENER EL DATO 3 DE LOS NODOS*/
        public E getData3 () {
            return this.data3;
        }

        /**MÉTODO PARA ESTABLECER EL DATO 3 DE LOS NODOS*/
        public void setData3 (E data) {
            this.data3 = data;
        }
        
        /**MÉTODO PARA OBTENER EL DATO 4 DE LOS NODOS*/
        public E getData4 () {
            return this.data4;
        }

        /**MÉTODO PARA ESTABLECER EL DATO 4 DE LOS NODOS*/
        public void setData4 (E data) {
            this.data4 = data;
        }
    }

    /**CONSTRUCTOR DE LA CLASE DOUBLELIST*/
    public DoubleList () {
            this.firstNode = null;
            this.lastNode = null;
            this.size = 0;
    }

    /**MÉTODO PARA DETERMINAR SI LA LISTA ESTÁ VACÍA*/
    public boolean isEmpty() { 
        return firstNode == null;
    }

    /**MÉTODO PARA MOSTRAR LA LISTA EN PANTALLA*/
    public void printList() { 
        if (isEmpty()) {
            System.err.println("Sorry! Empty List");
        }
        else {
            StringBuilder result = new StringBuilder();
            Node aux = firstNode;
            for (int i = 0; i < this.size && aux != null; i++) {
                result.append(aux.data1);
                result.append(" ");
                result.append(aux.data2);
                result.append(" ");
                result.append(aux.data3);
                result.append(" ");
                result.append(aux.data4);
                result.append("\n");
                aux = aux.next;
            }
            System.out.println(result);
        }
    }

    /**MÉTODO PARA AGREGAR ELEMENTOS AL FINAL DE LA LISTA*/
    public void addEnd(E inputData1, E inputData2, E inputData3, E inputData4) {
        if (isEmpty()) {
            firstNode = new Node(inputData1, inputData2, inputData3, inputData4);
            firstNode.previous = null;
        }
        else {
            Node aux = firstNode;
            while(aux.next != null) {
                aux = aux.next;
            }
            aux.next = new Node(inputData1, inputData2, inputData3, inputData4);
            aux.next.previous = aux;
        }
        this.size++;
    }

    /**MÉTODO PARA ELIMINAR EL PRIMER ELEMENTO DE LA LISTA*/
    public void deleteBeginning() {
        if (isEmpty()) {
            throw new Error("Sorry! Not found elements");
        }
        else {
            if(firstNode.next == null) {
                firstNode = null;
            }
            else {
                firstNode = firstNode.next;
                firstNode.previous = null;
            }
            this.size--;
        }	
    }
    /**MÉTODO PARA OBTENER EL TAMAÑO DE LA LISTA*/
    public int getSize () {
        return this.size;
    }

    /**MÉTODO PARA OBTENER EL ELEMENTO EN UNA POSICIÓN DETERMINADA DE LA LISTA*/
    public E getElementPosition(int pos, int data) {
        E result = null;
        if (data == 1) {
            result = (E) this.getNode(pos).data1;
        }
        else if (data == 2) {
            result = (E) this.getNode(pos).data2;
        }
        else if (data == 3) {
            result = (E) this.getNode(pos).data3;
        }
        else if (data == 4) {
            result = (E) this.getNode(pos).data4;
        }
        return result;
    }

    /**MÉTODO PARA OBTENER EL NODO EN UNA POSICIÓN DETERMINADA DE LA LISTA*/
    public Node getNode(int pos) {
        if (pos >= this.getSize() || pos < 0) {
                return null;
        }
        Node actualNode = this.firstNode;
        for (int i = 0; i < pos ; i++) {
            actualNode = actualNode.next;
        }
        return actualNode;
    }

    /**MÉTODO PARA INTERCAMBIAR POSICIÓN DE LOS NODOS*/
    public void swap(Node nodex, Node nodey) {
        E element1 = (E) nodex.getData1();
        E element2 = (E) nodex.getData2();
        E element3 = (E) nodex.getData3();
        E element4 = (E) nodex.getData4();
        nodex.setData1(nodey.getData1());
        nodex.setData2(nodey.getData2());
        nodex.setData3(nodey.getData3());
        nodex.setData4(nodey.getData4());
        nodey.setData1(element1);
        nodey.setData2(element2);
        nodey.setData3(element3);
        nodey.setData4(element4);
    }

    /**ALGORITMO DE ORDENAMIENTO BUBBLESORT ADAPTADO A STRINGS*/
    public void bubbleSort (int index) {
        for (int i = this.getSize() - 1; i > 0; i--) {
            for (int j = 0; j < i; j++) {
                if((this.getElementPosition(j + 1, index).toString().compareTo(this.getElementPosition(j, index).toString())) < 0) {
                    this.swap(this.getNode(j), this.getNode(j + 1));
                }
            }
        }
    }        
}